class Predictor:
    def setup(self):
        print("did setup")

    def predict(self):
        print("did predict")
